//
//  urlVC.swift
//  bagavathGeetha
//
//  Created by Ramu on 5/20/19.
//  Copyright © 2019 Ramu. All rights reserved.
//urlVC

import UIKit
import WebKit
// creating web view
class urlVC: UIViewController {
    @IBOutlet weak var web: WKWebView!
    var url = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        web.load(URLRequest(url: URL(string: url)!))
        
    }
    
    
    
}
