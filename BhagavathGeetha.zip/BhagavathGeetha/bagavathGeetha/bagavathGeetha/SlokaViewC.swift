//
//  slokaTableViewC.swift
//  bagavathGeetha
//
//  Created by Ramu on 5/20/19.
//  Copyright © 2019 Ramu. All rights reserved.

//

import UIKit
import WebKit
// creating web view
class slokaTableViewC: UIViewController, UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "Sloka")
    cell?.textLabel?.text = titles[indexPath.row]
        cell?.backgroundColor = .cyan
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         let a = self.storyboard?.instantiateViewController(withIdentifier: "UrlVC") as! urlVC
        if indexPath.row == 0{
            a.url = links["Shloka1"]!
        }else if indexPath.row == 1 {
            a.url = links["Shloka2"]!
        }else if indexPath.row == 2 {
            a.url = links["Shloka3"]!
        }else if indexPath.row == 3 {
            a.url = links["Shloka4"]!
        }else if indexPath.row == 4 {
            a.url = links["Shloka5"]!
        }else if indexPath.row == 5  {
            a.url = links["Shloka6"]!
        }else if indexPath.row == 6{
            a.url = links["Shloka7"]!
        }
        self.navigationController?.pushViewController(a, animated: true)
    }
  
    
    var links = [String : String]()
    var titles = ["Shloka1","Shloka2","Shloka3","Shloka4","Shloka5","Shloka6","Shloka7"]
    @IBOutlet weak var table: UITableView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
        table.register(UITableViewCell.self, forCellReuseIdentifier: "Sloka")
        print(links)
        // Do any additional setup after loading the view.
    }
    
    
  
   
}
