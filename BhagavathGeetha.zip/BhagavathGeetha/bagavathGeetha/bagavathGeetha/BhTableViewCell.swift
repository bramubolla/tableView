//
//  BhTableViewCell.swift
//  bagavathGeetha
//
//  Created by Ramu on 5/20/19.
//  Copyright © 2019 Ramu. All rights reserved.
//

import UIKit

class BhTableViewCell: UITableViewCell {
    
    @IBOutlet weak var godImage: UIImageView!
    
    
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
