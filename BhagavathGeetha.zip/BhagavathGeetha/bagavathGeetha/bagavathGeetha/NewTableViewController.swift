//
//  NewTableViewController.swift
//  bagavathGeetha
//
//  Created by Ramu on 5/20/19.
//  Copyright © 2019 Ramu. All rights reserved.
//

import UIKit

class NewTableViewController: UITableViewController,UISearchResultsUpdating {
    
    
    
    var bhagavathArr = [["chapter1":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/1/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/1/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/1/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/1/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/1/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/1/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/1/verse/7"]],
                                           ["chapter2":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/2/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/2/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/2/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/2/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/2/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/2/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/2/verse/7"]],
                                           ["chapter3":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/3/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/3/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/3/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/3/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/3/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/3/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/3/verse/7"]],
                                           ["chapter4":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/4/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/4/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/4/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/4/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/4/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/4/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/4/verse/7"]],
                                           ["chapter5":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/5/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/5/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/5/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/5/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/5/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/5/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/5/verse/7"]],
                                           ["chapter6":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/6/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/6/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/6/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/6/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/6/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/6/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/6/verse/7"]],
                                           ["chapter7":["Shloka1":"https://www.holy-bhagavad-gita.org/chapter/7/verse/1",
                                                        "Shloka2":"https://www.holy-bhagavad-gita.org/chapter/7/verse/2",
                                                        "Shloka3":"https://www.holy-bhagavad-gita.org/chapter/7/verse/3",
                                                        "Shloka4":"https://www.holy-bhagavad-gita.org/chapter/7/verse/4",
                                                        "Shloka5":"https://www.holy-bhagavad-gita.org/chapter/7/verse/5",
                                                        "Shloka6":"https://www.holy-bhagavad-gita.org/chapter/7/verse/6",
                                                        "Shloka7":"https://www.holy-bhagavad-gita.org/chapter/7/verse/7"]]
    ]
    
    
    var bhagavathArr1 = ["ch1","ch2","ch3","ch4","ch5","ch6","ch7"]
    var filteredArr = [String]()
    var filteredArr1 = [String]()
    var sc:UISearchController!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let A = UINib(nibName: "BhTableViewCell", bundle: nil)
        tableView.register(A, forCellReuseIdentifier: "aaa")
        
        

        // Uncomment the following line to preserve selection between presentations
       self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
         self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        createUI()
    }

    // MARK: - Table view data source

   
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    

  
    // Override to support editing the table view.
   

    
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func createUI()
    {
        
        sc = UISearchController(searchResultsController: nil)
        tableView.tableHeaderView=sc.searchBar
    
        sc.searchResultsUpdater=self
        sc.searchBar.showsBookmarkButton = true
        sc.searchBar.placeholder = "search"
        sc.searchBar.showsCancelButton = true
        sc.searchBar.showsScopeBar = true
       
    }
    func updateSearchResults(for searchController: UISearchController) {
        print("searching in a searchBar \(searchController.searchBar.text!)")
        
        
        let predicate = NSPredicate(format: "SELF Contains[c]%@",searchController.searchBar.text!)
        
        filteredArr = (bhagavathArr as NSArray).filtered(using:predicate) as![String]
        filteredArr1 = (bhagavathArr1 as NSArray).filtered(using:predicate) as![String]
        
        print(filteredArr)
        
        tableView.reloadData()
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        print("cfghfghkk")
        return 1
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Bhagavad Gita"
        
        
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(259)
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
       
            if sc.isActive == true{
                
                return filteredArr.count
            }
            else{
                return bhagavathArr.count
           
        }
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
            let cell = tableView.dequeueReusableCell(withIdentifier: "aaa") as! BhTableViewCell
            var a:String = "\(bhagavathArr[indexPath.row].keys)"
        
        a.removeFirst()
        a.removeFirst()
        a.removeLast()
        a.removeLast()
        print(a)
            if(sc.isActive == true)
            {
                
                cell.godImage.image = UIImage(named:filteredArr1[indexPath.row])
                cell.name.text=filteredArr[indexPath.row]
                return cell
                
            }else{
                cell.godImage.image = UIImage(named:bhagavathArr1[indexPath.row])

                cell.name.text = a
                print(cell.name.text!)
                cell.backgroundColor = UIColor.brown
                return cell
                
            }
        
        
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        
        
        let a = self.storyboard?.instantiateViewController(withIdentifier: "SlokaViewC") as! slokaTableViewC
        if indexPath.row == 0{
            a.links = bhagavathArr[0]["chapter1"]!
        }else if indexPath.row == 1 {
            a.links = bhagavathArr[1]["chapter2"]!
        }else if indexPath.row == 2 {
            a.links = bhagavathArr[2]["chapter3"]!
        }else if indexPath.row == 3 {
            a.links = bhagavathArr[3]["chapter4"]!
        }else if indexPath.row == 4 {
            a.links = bhagavathArr[4]["chapter5"]!
        }else if indexPath.row == 5  {
            a.links = bhagavathArr[5]["chapter6"]!
        }else if indexPath.row == 6{
            a.links = bhagavathArr[6]["chapter7"]!
        }
 

            self.navigationController?.pushViewController(a, animated: true)
//
        
        
        
    }

}
