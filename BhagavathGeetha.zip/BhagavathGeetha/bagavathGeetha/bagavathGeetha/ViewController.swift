//
//  ViewController.swift
//  bagavathGeetha
//
//  Created by Ramu on 5/20/19.
//  Copyright © 2019 Ramu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

