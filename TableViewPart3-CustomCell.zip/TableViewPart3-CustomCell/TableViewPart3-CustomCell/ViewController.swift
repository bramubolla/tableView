//
//  ViewController.swift
//  TableViewPart3-CustomCell
//
//  Created by Venkatesh on 5/11/19.
//  Copyright © 2019 Venkatesh. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    // Actors Name Array which is used to display the actor names in table view
    var actors = [["Mahesh Babu":["Language":"Telugu","Industry":"TollyWood"]],["Vijay Deverakonda":["Language":"Telugu","Industry":"TollyWood"]],["Allu Arjun":["Language":"Telugu","Industry":"TollyWood"]],["Prabhas":["Language":"Telugu","Industry":"TollyWood"]],["Surya":["Language":"Tamil","Industry":"Kollywood"]],["Vishal":["Language":"Tamil","Industry":"Kollywood"]],["Salman Khan":["Language":"Hindi","Industry":"BollyWood"]],["Hrithik Roshan":["Language":"Hindi","Industry":"BollyWood"]]]
    
    // cricketers Name Array which is used to display the cricketers names in table view
    var cricketers = [["MS Dhoni":["TestMatch":["Matches":"90","RunsScored":"4876","Batting Average":"38.09","100s":"6/33","TopScore":"243"],"OdiMatch":["Matches":"100","RunsScored":"6613","Batting Average":"53.76","100s":"25/20","TopScore":"243"],"T20Match":["Matches":"100","RunsScored":"6613","Batting Average":"53.76","100s":"25/20","TopScore":"243"]]],["Virat Kohli":["TestMatch":["Matches":"77","RunsScored":"6613","Batting Average":"53.76","100s":"25/20","TopScore":"243"],"OdiMatch":["Matches":"227","RunsScored":"9843","Batting Average":"59.57","100s":"41/49","TopScore":"183"],"T20Match":["Matches":"67","RunsScored":"2263","Batting Average":"50.28","100s":"0/20","TopScore":"90"]]],["Rohit Sharma":["TestMatch":["Matches":"27","RunsScored":"1585","Batting Average":"39.62","100s":"3/10","TopScore":"177"],"OdiMatch":["Matches":"206","RunsScored":"8010","Batting Average":"47.4","100s":"22/41","TopScore":"264"],"T20Match":["Matches":"94","RunsScored":"2331","Batting Average":"32.90","100s":"4/16","TopScore":"118"]]],["Shikhar Dhawan":["TestMatch":["Matches":"27","RunsScored":"1585","Batting Average":"39.62","100s":"3/10","TopScore":"177"],"OdiMatch":["Matches":"206","RunsScored":"8010","Batting Average":"47.4","100s":"22/41","TopScore":"264"],"T20Match":["Matches":"94","RunsScored":"2331","Batting Average":"32.90","100s":"4/16","TopScore":"118"]]],["K.L Rahul":["TestMatch":["Matches":"27","RunsScored":"1585","Batting Average":"39.62","100s":"3/10","TopScore":"177"],"OdiMatch":["Matches":"206","RunsScored":"8010","Batting Average":"47.4","100s":"22/41","TopScore":"264"],"T20Match":["Matches":"94","RunsScored":"2331","Batting Average":"32.90","100s":"4/16","TopScore":"118"]]]]
    
    // politicians Name Array which is used to display the politicians names in table view
var politicians = [["Narendra Modi":["State":"Dehli","Party":"BJP"]],["Rahul Gandhi":["State":"Dehli","Party":"Congress"]],["K. Chandrashekar Rao":["State":"Telegana","Party":"TRS"]],["N. Chandrababu Naidu":["State":"Andhra Pradesh","Party":"TDP"]],["Mamata Banerjee":["State":"West Bengal","Party":"All India Trinamool Congress"]],["Mayawati":["State":"Uttar Pradesh","Party":"Bahujan Samaj Party"]]]
    
    var celebritiesTV:UITableView! // creating table view
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // creating framing and viewing of tableview
        celebritiesTV = UITableView(frame: view.bounds, style: .grouped)
        celebritiesTV.backgroundColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        celebritiesTV.delegate = self
        celebritiesTV.dataSource = self
        let politicianCell = UINib(nibName: "PoliticiansCell", bundle: nil)
        celebritiesTV.register(politicianCell, forCellReuseIdentifier: "abc")
        let actorCell = UINib(nibName: "ActorsCell", bundle: nil)
        celebritiesTV.register(actorCell, forCellReuseIdentifier: "actor")
        let cricketerCell = UINib(nibName: "CricketersCell", bundle: nil)
        celebritiesTV.register(cricketerCell, forCellReuseIdentifier: "cricket")
        view.addSubview(celebritiesTV)
        
    }
    
    // Using tableview datasource function to display the rows in a section
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return actors.count}
        else if section == 1{
            return politicians.count}
        else{
            return cricketers.count}
    }
    
    // Using tableview datasource function to display the cells in a section
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "actor", for: indexPath) as! ActorsCell
            
            var a:String = "\(actors[indexPath.row].keys)"
            a.removeFirst()
            a.removeLast()
            a.removeFirst()
            a.removeLast()
            
            cell.actorName.text = a
            cell.actorPlace.text = "\(actors[indexPath.row][a]!["Industry"]!)"
            cell.actorLanguage.text = "\(actors[indexPath.row][a]!["Language"]!)"
            cell.actorImage.image = UIImage(named: a)
            return cell
        }
        else if (indexPath.section == 1){
            let cell = tableView.dequeueReusableCell(withIdentifier: "abc", for: indexPath) as! PoliticiansCell
            var a:String = "\(politicians[indexPath.row].keys)"
            a.removeFirst()
            a.removeLast()
            a.removeFirst()
            a.removeLast()
            
            cell.politicianName.text = a
            cell.politicianState.text = "\(politicians[indexPath.row][a]!["State"]!)"
            cell.politicianParty.text = "\(politicians[indexPath.row][a]!["Party"]!)"
            cell.politicianImage.image = UIImage(named: a)
            cell.politicianImage.layer.borderWidth = 1
            cell.politicianImage.layer.masksToBounds = false
            cell.politicianImage.layer.borderColor = UIColor.black.cgColor
            cell.politicianImage.layer.cornerRadius = cell.politicianImage.frame.height/2
            cell.politicianImage.clipsToBounds = true
            cell.flagImage.image = UIImage(named: a+" Party")
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cricket", for: indexPath) as! CricketersCell
            
            var a:String = "\(cricketers[indexPath.row].keys)"
            a.removeFirst()
            a.removeLast()
            a.removeFirst()
            a.removeLast()
            
             cell.cricketerName.text = a
             cell.cricketerTestMatchs.text = "\(cricketers[indexPath.row][a]!["TestMatch"]!["Matches"]!)"
             lblBorderAndColour(label: cell.cricketerTestMatchs)
             cell.cricketerTestRuns.text = "\(cricketers[indexPath.row][a]!["TestMatch"]!["RunsScored"]!)"
             lblBorderAndColour(label: cell.cricketerTestRuns)
             cell.cricketerTestBtngAvg.text = "\(cricketers[indexPath.row][a]!["TestMatch"]!["Batting Average"]!)"
             lblBorderAndColour(label: cell.cricketerTestBtngAvg)
             cell.cricketerTest100.text = "\(cricketers[indexPath.row][a]!["TestMatch"]! ["100s"]!)"
             lblBorderAndColour(label: cell.cricketerTest100)
             cell.cricketerTestTopScr.text = "\(cricketers[indexPath.row][a]!["TestMatch"]!["TopScore"]!)"
             lblBorderAndColour(label: cell.cricketerTestTopScr)
            
            cell.cricketerOdiMatchs.text = "\(cricketers[indexPath.row][a]!["OdiMatch"]!["Matches"]!)"
            lblBorderAndColour(label: cell.cricketerOdiMatchs)
            cell.cricketerOdiRuns.text = "\(cricketers[indexPath.row][a]!["OdiMatch"]!["RunsScored"]!)"
            lblBorderAndColour(label: cell.cricketerOdiRuns)
            cell.cricketerOdiBatngAvg.text = "\(cricketers[indexPath.row][a]!["OdiMatch"]!["Batting Average"]!)"
            lblBorderAndColour(label: cell.cricketerOdiBatngAvg)
            cell.cricketerOdi100.text = "\(cricketers[indexPath.row][a]!["OdiMatch"]!["100s"]!)"
            lblBorderAndColour(label: cell.cricketerOdi100)
            cell.cricketerOdiTopScr.text = "\(cricketers[indexPath.row][a]!["OdiMatch"]!["TopScore"]!)"
            lblBorderAndColour(label: cell.cricketerOdiTopScr)
            
            
            cell.cricketerT20Matchs.text = "\(cricketers[indexPath.row][a]!["T20Match"]!["Matches"]!)"
            lblBorderAndColour(label: cell.cricketerT20Matchs)
            cell.cricketerT20Runs.text = "\(cricketers[indexPath.row][a]!["T20Match"]!["RunsScored"]!)"
            lblBorderAndColour(label: cell.cricketerT20Runs)
            cell.cricketerT20BatngAvg.text = "\(cricketers[indexPath.row][a]!["T20Match"]!["Batting Average"]!)"
            lblBorderAndColour(label: cell.cricketerT20BatngAvg)
            cell.cricketerT20100.text = "\(cricketers[indexPath.row][a]!["T20Match"]!["100s"]!)"
            lblBorderAndColour(label: cell.cricketerT20100)
            cell.cricketerT20TopScr.text = "\(cricketers[indexPath.row][a]!["T20Match"]!["TopScore"]!)"
            lblBorderAndColour(label: cell.cricketerT20TopScr)
            

            cell.cricketerImage.image = UIImage(named: a)
            cell.cricketerLogo.image = UIImage(named: "India Logo")
            return cell
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{return 300.0}
        else {return 374.0}
    }
    
    // Using tableview datasource function to display the number of sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let webViewPage = storyboard?.instantiateViewController(withIdentifier: "webviewvc") as! WebViewVC
//        let abc = celebrities[indexPath.section][indexPath.row]
//        let name1 = abc.replacingOccurrences(of: " ", with: "_")
//        webViewPage.name = name1
//        self.navigationController?.pushViewController(webViewPage, animated: true)
    }
    
    // Using tableview datasource function to give a header titles
   func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section==0{return "Actors"}
        else if section==1{return "Politicians"}
        else {return "Cricketers"}
      }
    

    
//     Using tableview datasource function to display the titles
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return ["A","P","C"]
    }
    
    // Using tableview datasource function to when ever we select the title at the time this function will executes
    func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        if title == "A"{return 0}
        else if title == "P"{return 1}
        else {return 2}
    }
    
//     Using tableview datasource function to the header title font and colour
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        let header = view as! UITableViewHeaderFooterView
        header.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        header.textLabel?.font = UIFont(name: "Times New Roman", size: 38)!
        header.textLabel?.textColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
    }
    
    func lblBorderAndColour(label:UILabel){
        label.layer.borderWidth=0.5
        label.layer.borderColor=#colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
    }
    
}



