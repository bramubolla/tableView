//
//  PoliticiansCell.swift
//  TableViewPart3-CustomCell
//
//  Created by Venkatesh on 5/11/19.
//  Copyright © 2019 Venkatesh. All rights reserved.
//

import UIKit

class PoliticiansCell: UITableViewCell {

    @IBOutlet weak var flagImage: UIImageView!
    
    @IBOutlet weak var politicianImage: UIImageView!
    
    @IBOutlet weak var politicianName: UILabel!
    
    @IBOutlet weak var politicianParty: UILabel!
    
    @IBOutlet weak var politicianState: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
