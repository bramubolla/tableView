//
//  CricketersCell.swift
//  TableViewPart3-CustomCell
//
//  Created by Venkatesh on 5/11/19.
//  Copyright © 2019 Venkatesh. All rights reserved.
//

import UIKit

class CricketersCell: UITableViewCell {

    @IBOutlet weak var cricketerImage: UIImageView!
    @IBOutlet weak var cricketerLogo: UIImageView!
    
    @IBOutlet weak var cricketerTestMatchs: UILabel!
    @IBOutlet weak var cricketerName: UILabel!
    @IBOutlet weak var cricketerTestRuns: UILabel!
    @IBOutlet weak var cricketerTestBtngAvg: UILabel!
    @IBOutlet weak var cricketerTest100: UILabel!
    @IBOutlet weak var cricketerTestTopScr: UILabel!
    
    @IBOutlet weak var cricketerOdiMatchs: UILabel!
    @IBOutlet weak var cricketerOdiRuns: UILabel!
    @IBOutlet weak var cricketerOdiBatngAvg: UILabel!
    @IBOutlet weak var cricketerOdi100: UILabel!
    @IBOutlet weak var cricketerOdiTopScr: UILabel!
    
    @IBOutlet weak var cricketerT20Matchs: UILabel!
    @IBOutlet weak var cricketerT20Runs: UILabel!
    @IBOutlet weak var cricketerT20BatngAvg: UILabel!
    
    @IBOutlet weak var cricketerT20TopScr: UILabel!
    @IBOutlet weak var cricketerT20100: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
