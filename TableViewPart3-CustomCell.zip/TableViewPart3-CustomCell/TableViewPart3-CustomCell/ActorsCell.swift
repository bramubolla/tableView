//
//  ActorsCell.swift
//  TableViewPart3-CustomCell
//
//  Created by Venkatesh on 5/11/19.
//  Copyright © 2019 Venkatesh. All rights reserved.
//

import UIKit

class ActorsCell: UITableViewCell {

    
    @IBOutlet weak var actorImage: UIImageView!
    
    @IBOutlet weak var actorName: UILabel!
    
    @IBOutlet weak var actorPlace: UILabel!
    
    @IBOutlet weak var actorLanguage: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
