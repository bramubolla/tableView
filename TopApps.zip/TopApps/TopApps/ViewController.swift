//
//  ViewController.swift
//  TopApps
//
//  Created by Prem Kumar on 06/05/19.
//  Copyright © 2019 Prem Kumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    //%%%%%%%%%%%%%%%%%%%%%%%%%%% creating all Variables %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    var request : URLRequest!
    
    var dataTask : URLSessionDataTask!
    
    var imageView : UIImageView!
    
    
    @IBOutlet weak var segment: UISegmentedControl!
    
    var label : UILabel!
    
    var imageViewGroup = [UIImageView]()
    var labelArray = [UILabel]()
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    @IBOutlet weak var addedView: UIView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.tintColor = UIColor.blue
        
        let navigationTitleFont = UIFont(name: "Chalkduster", size: 30)!
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: navigationTitleFont]
        
        UISegmentedControl.appearance().setTitleTextAttributes(NSDictionary(objects: [UIFont.systemFont(ofSize: 35.0)],forKeys: [NSAttributedString.Key.font as NSCopying]) as? [AnyHashable : Any] as! [NSAttributedString.Key : Any],for: UIControl.State.normal)
    
    }
     //%%%%%%%%%%%%%%%%%%%%%%%%%%% creating function for segment controller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    @IBAction func onCuntrySelect(_ sender: UISegmentedControl) {
        
        
     //%%%%%%%%%%%%%%%%%%%%%%%%%%% Using activity indicator %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        switch sender.titleForSegment(at: sender.selectedSegmentIndex) {
        
        case "INDIA":
            
            activityIndicator.startAnimating()
            
            print("Top Ten Apps in \(sender.titleForSegment(at: sender.selectedSegmentIndex)!)")
            
            getTopTenApps(country: "in")
            
            
            
        case "USA":
            
            activityIndicator.startAnimating()
            
            print("Top Ten Apps in \(sender.titleForSegment(at: sender.selectedSegmentIndex)!)")
            
            getTopTenApps(country: "us")
            
            
            
        case "UK":
            
            activityIndicator.startAnimating()
            
            print("Top Ten Apps in \(sender.titleForSegment(at: sender.selectedSegmentIndex)!)")
            
            getTopTenApps(country: "gb")
            
            
            
        default:
            
            print("default")
            
        }
        
    }
    
    //%%%%%%%%%%%%%%%%%%%%%%%%%%% creating function for top ten apps %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    func getTopTenApps(country : String) {
        
        
        
        request = URLRequest(url: URL(string: "https://rss.itunes.apple.com/api/v1/\(country)/ios-apps/top-free/all/10/explicit.json")!)
        
        request.httpMethod = "GET"
        
        dataTask = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
            
            do {
                
                let receivedData = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:Any]
                
                let feed = receivedData["feed"] as! [String:Any]
                
                let results = feed["results"] as! [[String:Any]]
                
                for result in results {
                    
                    print(result["name"]!)
                    
                }
                print()
                DispatchQueue.main.async {
                    
                    
                    
                    self.activityIndicator.stopAnimating()
                    
                    
                    
                    if(self.imageViewGroup.isEmpty && self.labelArray.isEmpty) {
                        
                        
                        
                        var pointY = 100
                        
                        
                        
                        for result in results {
                            
                            
                            
                            self.imageView = UIImageView(frame: CGRect(x: 0, y: pointY, width: 120, height: 90))
                            
                            self.imageView.contentMode = .scaleToFill
                            self.imageView.layer.borderColor = UIColor.black.cgColor
                            self.imageView.layer.cornerRadius = self.imageView.frame.height/2
                            self.imageView.clipsToBounds = true
                            self.imageView.layer.masksToBounds = true
                
                            
                            do {
                                
                                self.imageView.image = try UIImage(data: Data(contentsOf: URL(string: result["artworkUrl100"] as! String)!))
                                
                            } catch {
                                
                                print("imageView Error")
                                
                            }
                            
                            self.addedView.addSubview(self.imageView)
                            
                            self.imageViewGroup.append(self.imageView)
                            
                            
                            
                            self.label = UILabel(frame: CGRect(x: 140, y: pointY, width: 180, height: 70))
                            
    
                            
                            self.label.text = result["name"]! as? String
                            
                            self.label.textColor = .blue
                            
                            self.label.numberOfLines = 2
            
                            self.label.font = UIFont(name: "chalkduster", size: 20)
                            
                            self.addedView.addSubview(self.label)
                            
                            self.labelArray.append(self.label)
                            
                            
                            
                            pointY += 100
                            
                        }
                        
                        
                        
                    }
                    
                    
                    
                    if(self.imageViewGroup.count > 0 && self.labelArray.count > 0) {
                        
                        
                        
                        var imageViewindex = 0
                        
                        
                        
                        for imageView in self.imageViewGroup {
                            
                            
                            
                            do {
                                
                                imageView.image = try UIImage(data: Data(contentsOf: URL(string: results[imageViewindex]["artworkUrl100"] as! String)!))
                                
                            } catch {
                                
                                print("image _ View Error")
                                
                            }
                            
                            imageViewindex += 1
                            
                        }
                        
                        
                        
                        var labelIndex = 0
                        
                        
                        
                        for label in self.labelArray {
                            
                            label.text = results[labelIndex]["name"]! as? String
                            
                            labelIndex += 1
                        }}}
            } catch {
                
                print("Error")
                
            }
          
        })
        dataTask.resume()
        
    }
}
