//
//  EditingTableView.swift
//  EditingTableView
//
//  Created by ahammed on 5/14/19.
//  Copyright © 2019 ahammed. All rights reserved.
//

import UIKit

class EditingTableView: UITableViewController{
    var indiaTeam = ["DHONI","KOHLI","ROHIT","HARDIK","BHUVI","BUMRAH","KULDEEP"]
    var indiaTeamImages = ["dhoni","kohli","rohit","hardik","bhuvi","bumrah","kuldeep"]
    var indiaTeamFlag = ["flag","flag","flag","flag","flag","flag","flag"]
    
    var australiaTeam = ["WARNER","WATSON","SMITH","MAXWELL","FINCH"]
    var australiaTeamImages = ["warner","watson","smith","maxwell","finch"]
    var australiaTeamFlag = ["ausFlag","ausFlag","ausFlag","ausFlag","ausFlag"]
    
    var africaTeam = ["DEKOCK","AMLA","STEYN","DU PLESSIS"]
    var africaTeamImages = ["dekock","amla","steyn","duplessis"]
    var africaTeamFlag = ["saflag","saflag","saflag","saflag"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let indiaPlayers = UINib(nibName: "CustomCell", bundle: nil)
         tableView.register(indiaPlayers, forCellReuseIdentifier: "aaa")
        let ausPlayers = UINib(nibName: "AustraliaCrickters", bundle: nil)
        tableView.register(ausPlayers, forCellReuseIdentifier: "bbb")
        let africaPlayers = UINib(nibName: "AfricaCrickters", bundle: nil)
       tableView.register(africaPlayers, forCellReuseIdentifier: "ccc")
         self.navigationItem.rightBarButtonItem = self.editButtonItem
        
       
    }
   
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0){
            return indiaTeam.count
        }
        else if(section == 1){
            return australiaTeam.count
        }else{
            return africaTeam.count
        }
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0){
            return "India Team"
        }
        else if(section == 1){
            return "Australia Team"
        }
        else {
            
         return "Africa Team"
        }
        
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return CGFloat(329)
        
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        if(indexPath.row % 2 == 0){
            
            return UITableViewCell.EditingStyle.insert
        }else{
            return UITableViewCell.EditingStyle.delete
            
        }
        
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {

        if(indexPath.section == 0){
            if(editingStyle == UITableViewCell.EditingStyle .insert){
            indiaTeam.insert("\(indiaTeam[indexPath.row])", at: indexPath.row)
                tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.middle)
         }
            else if (editingStyle == UITableViewCell.EditingStyle .delete){
                indiaTeam.remove(at: indexPath.row )
                tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.middle)

        }

        }
        else if(indexPath.section == 1){
            if(editingStyle == UITableViewCell.EditingStyle .insert){
                australiaTeam.insert("\(australiaTeam[indexPath.row])", at: indexPath.row)
                tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.middle)
            }
            else if (editingStyle == UITableViewCell.EditingStyle .delete){
                australiaTeam.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.middle)
                
            }
            
        }else{
            if(editingStyle == UITableViewCell.EditingStyle .insert){
                africaTeam.insert("\(africaTeam[indexPath.row])", at: indexPath.row)
                tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.middle)
            }
            else if (editingStyle == UITableViewCell.EditingStyle .delete){
                africaTeam.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.middle)
                
            }
            
        }
            
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.section == 0){
        let cell = tableView.dequeueReusableCell(withIdentifier: "aaa",for:indexPath) as! CustomCell
        cell.name.text = indiaTeam[indexPath.row]
        cell.mainImage.image = UIImage(named:indiaTeamImages[indexPath.row])
        cell.flagImage.image = UIImage(named: indiaTeamFlag[indexPath.row])
        
        return cell
        }
        else if(indexPath.section == 1){
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "bbb",for:indexPath) as! AustraliaCrickters
            cell2.ausTeamNames.text = australiaTeam[indexPath.row]
            cell2.ausTeamImages.image = UIImage(named:australiaTeamImages[indexPath.row])
            cell2.ausFlag.image = UIImage(named: australiaTeamFlag[indexPath.row])
            return cell2
        }
        else {
            
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "ccc",for:indexPath) as! AfricaCrickters
            cell1.africaTeamNames.text = africaTeam[indexPath.row]
            cell1.africaTeamImage.image = UIImage(named:africaTeamImages[indexPath.row])
            cell1.africaflag.image = UIImage(named: africaTeamFlag[indexPath.row])
            
            return cell1
            

    }
  
       
}
}
