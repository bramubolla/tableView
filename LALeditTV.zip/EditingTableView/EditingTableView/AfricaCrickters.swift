//
//  AfricaCrickters.swift
//  EditingTableView
//
//  Created by ahammed on 5/14/19.
//  Copyright © 2019 ahammed. All rights reserved.
//

import UIKit

class AfricaCrickters: UITableViewCell {

    @IBOutlet weak var africaflag: UIImageView!
    @IBOutlet weak var africaTeamImage: UIImageView!
    @IBOutlet weak var africaTeamNames: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
