//
//  AustraliaCrickters.swift
//  EditingTableView
//
//  Created by ahammed on 5/14/19.
//  Copyright © 2019 ahammed. All rights reserved.
//

import UIKit

class AustraliaCrickters: UITableViewCell {

    @IBOutlet weak var ausFlag: UIImageView!
    @IBOutlet weak var ausTeamImages: UIImageView!
    @IBOutlet weak var ausTeamNames: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
