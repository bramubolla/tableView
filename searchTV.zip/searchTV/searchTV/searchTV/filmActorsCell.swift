//
//  filmActorsCell.swift
//  searchTV
//
//  Created by Ramu on 5/17/19.
//  Copyright © 2019 Ramu. All rights reserved.
//

import UIKit

class filmActorsCell: UITableViewCell {
    
    
    
    
    @IBOutlet weak var actorImage: UIImageView!
    

    @IBOutlet weak var actorName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
