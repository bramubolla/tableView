//
//  actorsTV.swift
//  searchTV
//
//  Created by Ramu on 5/16/19.
//  Copyright © 2019 Ramu. All rights reserved.
//

import UIKit

class actorsTV: UITableViewController,UISearchResultsUpdating  {
    var actorsNameArr = ["Mahesh Babu","Vijay Deverakonda","Allu Arjun","Prabhas","Surya","Vishal","Salman Khan","Hrithik Roshan","Rana","Ravi Teja","Nani","Shirish"]
    var actorsImagesArr = ["Mahesh Babu","Vijay Deverakonda","Allu Arjun","Prabhas","Surya","Vishal","Salman Khan","Hrithik Roshan","Rana","Ravi Teja","Nani","Shirish"]
    var polticinsArr = ["KCR","MODI","NTR","KTR","RAHUL GANDHI","CBN"]
    var polticinsImagesArr = ["KCR","MODI","NTR","KTR","RAHUL GANDHI","CBN"]
    var polticinsFlag = ["flag trs","flag bjp","flag","flag trs","flag congres","flag"]
    var filteredArr = [String]()
    var filteredArr1 = [String]()
    
    var filteredPolArr = [String]()
    var filteredPolImageArr = [String]()
    var filteredPolFlagArr = [String]()
    var sc:UISearchController!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let A = UINib(nibName: "filmActorsCell", bundle: nil)
        tableView.register(A, forCellReuseIdentifier: "aaa")
        let B = UINib(nibName: "polticiansCell", bundle: nil)
        tableView.register(B, forCellReuseIdentifier: "abc")
       
       

        // Uncomment the following line to preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
       self.navigationItem.rightBarButtonItem = self.editButtonItem
        
      createUI()
        
    }

    // MARK: - Table view data source

    
   
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
   

 
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if(indexPath.section == 0){
        if editingStyle == .delete {
            // Delete the row from the data source
            actorsNameArr.remove(at: indexPath.row)
            actorsImagesArr.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.middle)
        } else if editingStyle == .insert {
            actorsNameArr.insert("\(actorsNameArr[indexPath.row])", at: indexPath.row)
            actorsImagesArr.insert("\(actorsNameArr[indexPath.row])", at: indexPath.row)
            tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.middle)
        }
            
        }else{
            if editingStyle == .delete {
                // Delete the row from the data source
                polticinsArr.remove(at: indexPath.row)
                polticinsFlag.remove(at: indexPath.row)
                polticinsImagesArr.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.middle)
            } else if editingStyle == .insert {
                polticinsArr.insert("\(polticinsArr[indexPath.row])", at: indexPath.row)
                polticinsFlag.insert("\(polticinsFlag[indexPath.row])", at: indexPath.row)
                polticinsImagesArr.insert("\(polticinsImagesArr[indexPath.row])", at: indexPath.row)

                tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.middle)
            }
            
        }
    }
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        if (indexPath.row % 2 == 0){
            return UITableViewCell.EditingStyle.insert
        }else{
            return UITableViewCell.EditingStyle.delete
    }
    }

   
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
        
      

    }
 

    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(270)
        
    }
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func createUI()
    {
        
        sc = UISearchController(searchResultsController: nil)
        tableView.tableHeaderView=sc.searchBar

        sc.searchResultsUpdater=self
        
        sc.searchBar.showsBookmarkButton = true
        sc.searchBar.placeholder = "search"
        sc.searchBar.showsCancelButton = true
        sc.searchBar.showsScopeBar = true
       sc.searchBar.scopeButtonTitles = ["actres","polticians"]
    }
    func updateSearchResults(for searchController: UISearchController) {
        print("searching in a searchBar \(searchController.searchBar.text!)")
        
        
        let predicate = NSPredicate(format: "SELF Contains[c]%@",searchController.searchBar.text!)
        
        filteredArr = (actorsNameArr as NSArray).filtered(using:predicate) as![String]
        filteredArr1 = (actorsImagesArr as NSArray).filtered(using: predicate) as! [String]
        filteredPolArr = (polticinsArr as NSArray).filtered(using: predicate) as! [String]
        filteredPolImageArr = (polticinsImagesArr as NSArray).filtered(using: predicate) as! [String]
        filteredPolFlagArr = (polticinsFlag as NSArray).filtered(using: predicate) as! [String]
        
        print(filteredArr)
        print(filteredArr1)
        print(filteredPolFlagArr)
        print(filteredPolImageArr)
        print(filteredPolArr)
        tableView.reloadData()
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0){
            return "Actres"
        }
        else {
            return "Polticians"
        }
        
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if(section==0){
        if sc.isActive == true{
        
        return filteredArr.count
        }
        else{
            return actorsNameArr.count
        }
        }else{
            if sc.isActive == true{
                return filteredPolArr.count
            }
            else{
                return polticinsArr.count
            }
        }
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.section == 0){
        let cell = tableView.dequeueReusableCell(withIdentifier: "aaa") as! filmActorsCell
        
      
        if(sc.isActive == true)
        {
            
            cell.actorImage.image = UIImage(named:filteredArr1[indexPath.row])
            cell.actorName.text=filteredArr[indexPath.row]
            return cell

        }else{
            cell.actorImage.image = UIImage(named:actorsImagesArr[indexPath.row])
            cell.actorName.text=actorsNameArr[indexPath.row]
            return cell

        }
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "abc") as! polticiansCell
            
            
            if(sc.isActive == true)
            {
                

                
                cell.polticianImage.image = UIImage(named:filteredPolImageArr[indexPath.row])
                cell.polticianName.text=filteredPolArr[indexPath.row]
               cell.polticianFlag.image = UIImage(named:polticinsFlag[indexPath.row])
                
                return cell
                
            }else{
                cell.polticianImage.layer.borderWidth = 1
                cell.polticianImage.layer.masksToBounds = false
                cell.polticianImage.layer.borderColor = UIColor.black.cgColor
                cell.polticianImage.clipsToBounds = true
                cell.polticianImage.layer.cornerRadius = cell.polticianImage.frame.height/2
                cell.polticianImage.image = UIImage(named:polticinsImagesArr[indexPath.row])
                cell.polticianFlag.image = UIImage(named:polticinsFlag[indexPath.row])
                cell.polticianName.text=polticinsArr[indexPath.row]
                return cell
                
            }
            
        }
    
    }
    


}
