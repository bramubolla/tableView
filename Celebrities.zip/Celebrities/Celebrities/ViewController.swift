//
//  ViewController.swift
//  Celebrities
//
//  Created by Bhukya on 5/10/19.
//  Copyright © 2019 Bhukya. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    //creating a table view
     var table:UITableView!
    //creating different arrays
    var actors = ["Mahesh Babu","Vijay Deverakonda","Nani","Prabhas","Trisha","Nayanthara","Samantha","Sai Pallavi"]
    var cricketers = ["MS Dhoni","Raina","Jadeja","KL Rahul","Smriti Mandhana","Mithali Raj","Harmanpreet Kaur","Veda Krishnamurthy"]
    var politicians = ["Rahul Gandhi","Narendra Modi","K.Chandrashekar Rao","N.Chandrababu Naidu","Sonia Gandhi","Mamata Banerjee","Mayawati","Jayalalithaa"]
    var selectedRow:[String] = ["https://en.wikipedia.org/wiki/Mahesh_Babu","https://en.wikipedia.org/wiki/Vijay_Deverakonda","https://en.wikipedia.org/wiki/Nani_(actor)","https://en.wikipedia.org/wiki/Prabhas","https://en.wikipedia.org/wiki/Trisha_(actress)","https://en.wikipedia.org/wiki/Nayanthara","https://en.wikipedia.org/wiki/Samantha_Akkineni","https://en.wikipedia.org/wiki/Sai_Pallavi","https://en.wikipedia.org/wiki/MS_Dhoni","https://en.wikipedia.org/wiki/Suresh_Raina","https://en.wikipedia.org/wiki/Ravindra_Jadeja","https://en.wikipedia.org/wiki/K._L._Rahul","https://en.wikipedia.org/wiki/Smriti_Mandhana","https://en.wikipedia.org/wiki/Mithali_Raj","https://en.wikipedia.org/wiki/Harmanpreet_Kaur","https://en.wikipedia.org/wiki/Veda_Krishnamurthy","https://en.wikipedia.org/wiki/Rahul_Gandhi","https://en.wikipedia.org/wiki/Narendra_Modi","https://en.wikipedia.org/wiki/K._Chandrashekar_Rao","https://en.wikipedia.org/wiki/N._Chandrababu_Naidu","https://en.wikipedia.org/wiki/Sonia_Gandhi","https://en.wikipedia.org/wiki/Mamata_Banerjee","https://en.wikipedia.org/wiki/Mayawati","https://en.wikipedia.org/wiki/Jayalalithaa"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barTintColor = #colorLiteral(red: 1, green: 0.8819669022, blue: 0.7585165562, alpha: 1)
        navigationController?.navigationBar.prefersLargeTitles = true

        createTableView()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func createTableView(){
        table = UITableView(frame: view.frame, style: UITableView.Style.grouped)
        table.delegate = self
        table.dataSource = self
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        view.addSubview(table)
        
    }
    // delegation method for table view
    func numberOfSections(in tableView: UITableView) -> Int {
           return 3
    }
    // set title for headers in table view
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0) {
            return "Actors"
        } else if(section == 1){
            return "Cricketers"
        }else {
            return "Politicians"
        }
    }
    // select the row values from arrays
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 1) {
            return actors.count
        } else if(section == 2){
            return cricketers.count
        }else {
            return politicians.count
        }
    }
    // creating a cell and assgining values
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.imageView?.frame = CGRect(x: 0, y: 0, width: 80, height: 80)
        cell.imageView?.layer.cornerRadius = (cell.imageView?.frame.size.height)!/2
        cell.imageView?.layer.borderWidth = 2.0
        cell.imageView?.clipsToBounds = true
        if(indexPath.section == 0){
            cell.textLabel?.text = "\(actors[indexPath.row])"
            cell.imageView?.image = UIImage(named: actors[indexPath.row])
        }else if (indexPath.section == 1){
            cell.textLabel?.text = "\(cricketers[indexPath.row])"
            cell.imageView?.image = UIImage(named: cricketers[indexPath.row])
        }else{
             cell.textLabel?.text = "\(politicians[indexPath.row])"
              cell.imageView?.image = UIImage(named: politicians[indexPath.row])
        }
        
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 80.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let wikiPage = self.storyboard?.instantiateViewController(withIdentifier: "mainToWiki") as! WikiViewController
        if(indexPath.section == 0){
            wikiPage.selected = selectedRow[indexPath.row]
            self.navigationController?.pushViewController(wikiPage, animated: true)
            
        }
        else if(indexPath.section == 1){
            wikiPage.selected = selectedRow[indexPath.row+8]
            self.navigationController?.pushViewController(wikiPage, animated: true)
        }
        else if(indexPath.section == 2){
            wikiPage.selected = selectedRow[indexPath.row+16]
            self.navigationController?.pushViewController(wikiPage, animated: true)
        }
       
    }

}

