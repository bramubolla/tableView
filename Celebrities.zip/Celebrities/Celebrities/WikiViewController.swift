//
//  WikiViewController.swift
//  Celebrities
//
//  Created by Bhukya on 5/10/19.
//  Copyright © 2019 Bhukya. All rights reserved.
//

import UIKit
import WebKit
// creating web view
class WikiViewController: UIViewController {
    var webView: WKWebView!
    var selected:String!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        webView = WKWebView()
        view = webView
        let url = URL(string: selected)!
        webView.load(URLRequest(url: url))
      
        // Do any additional setup after loading the view.
    }
    


}
